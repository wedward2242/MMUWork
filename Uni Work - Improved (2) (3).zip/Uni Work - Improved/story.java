

class story {
    public static String main() {
        String userStory = "And now you embark on your quest to become the best hero that you could have been";
        return userStory;
    }
}